﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for StorageManager
/// </summary>
public static class StorageManager
{
    public static UserAccount user;
    public static Address add;
    public static List<Request> lastSearchedRequests = new List<Request>();
}